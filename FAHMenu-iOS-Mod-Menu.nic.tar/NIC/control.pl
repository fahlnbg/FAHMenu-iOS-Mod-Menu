NIC->prompt("APPVERSION", "Version of the App", {default => "1.0"});

NIC->prompt("APPNAME", "Name of the App", {default => ""});

NIC->prompt("USER", "Who made the hack", {default => "fahlnbg"});

